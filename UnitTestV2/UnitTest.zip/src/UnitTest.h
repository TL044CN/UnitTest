#pragma once
#ifndef UT_H
#define UT_H

#include "TestCollection.h"
#include "Testable.h"

#endif