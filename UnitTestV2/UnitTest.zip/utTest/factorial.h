#pragma once
#include <cstdint>
#include <iostream>
#include <string>

int32_t factorial(int32_t number);
