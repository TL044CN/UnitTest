#pragma once
#include <cstdint>
#include <iostream>

int64_t fibonacci(int64_t zahl);
